# backtest.py
"""
Backtesting logic for multi-timeframe strategy.
"""
import numpy as np
import pandas as pd
from signals import generate_signals

def simple_backtest(df, ensemble_preds, threshold=0.1, initial_equity=10000, atr_col='1h_atr_14'):
    signals = generate_signals(df, ensemble_preds, threshold)
    equity = initial_equity
    equity_curve = [equity]
    position = 0
    entry_price = 0
    trade_log = []
    for i, row in df.iterrows():
        signal = signals[i]
        close = row['close']
        atr = row[atr_col]
        if position == 0:
            if signal == "Long":
                position = 1
                entry_price = close
                stop = close - 2 * atr
                target = close + 2 * atr
                trade_log.append({'Type': 'Long', 'Entry': close, 'Stop': stop, 'Target': target, 'Entry_idx': i})
            elif signal == "Short":
                position = -1
                entry_price = close
                stop = close + 2 * atr
                target = close - 2 * atr
                trade_log.append({'Type': 'Short', 'Entry': close, 'Stop': stop, 'Target': target, 'Entry_idx': i})
        elif position == 1:
            if close <= stop:
                pnl = stop - entry_price
                equity += pnl
                equity_curve.append(equity)
                position = 0
            elif close >= target:
                pnl = target - entry_price
                equity += pnl
                equity_curve.append(equity)
                position = 0
            else:
                equity_curve.append(equity)
        elif position == -1:
            if close >= stop:
                pnl = entry_price - stop
                equity += pnl
                equity_curve.append(equity)
                position = 0
            elif close <= target:
                pnl = entry_price - target
                equity += pnl
                equity_curve.append(equity)
                position = 0
            else:
                equity_curve.append(equity)
        else:
            equity_curve.append(equity)
    return equity_curve, trade_log, signals
