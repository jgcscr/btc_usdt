import pandas as pd
import tensorflow as tf # Make sure tensorflow is imported
import pickle # or joblib

from tensorflow.keras.models import load_model
from tensorflow.keras.losses import MeanSquaredError
import joblib
import zipfile
import os

# Load Deep Learning models (.h5) with custom objects
lstm_model = load_model('/content/drive/My Drive/btc_usdt_trading_pipeline/models/lstm_model.h5', custom_objects={'mse': MeanSquaredError()})
gru_model = load_model('/content/drive/My Drive/btc_usdt_trading_pipeline/models/gru_model.h5', custom_objects={'mse': MeanSquaredError()})
transformer_model = load_model('/content/drive/My Drive/btc_usdt_trading_pipeline/models/transformer_model.h5', custom_objects={'mse': MeanSquaredError()})

# Load Machine Learning models (.joblib)
rf_model = joblib.load('/content/drive/My Drive/btc_usdt_trading_pipeline/models/rf_best_model.joblib')
xgb_model = joblib.load('/content/drive/My Drive/btc_usdt_trading_pipeline/models/xgb_best_model.joblib')
arima_model = joblib.load('/content/drive/My Drive/btc_usdt_trading_pipeline/models/arima_model.joblib')
garch_model = joblib.load('/content/drive/My Drive/btc_usdt_trading_pipeline/models/garch_model.joblib')

# Unzip and load PPO trading agent (assuming it needs unzipping)
ppo_agent_path = '/content/drive/My Drive/btc_usdt_trading_pipeline/models/ppo_trading_agent.zip'
ppo_agent_dir = '/content/drive/My Drive/btc_usdt_trading_pipeline/models/ppo_trading_agent/'

# Unzip only if not already unzipped
if not os.path.exists(ppo_agent_dir):
    with zipfile.ZipFile(ppo_agent_path, 'r') as zip_ref:
        zip_ref.extractall(ppo_agent_dir)

# You will now have the PPO agent's files inside 'ppo_agent_dir'.
# (Loading the PPO agent depends on how it was saved — often requires Stable-Baselines3 or custom loading.)




import numpy as np

# Load the dataset
df_1m = pd.read_parquet('/content/drive/My Drive/btc_usdt_trading_pipeline/data/1m_btcusdt_365_days_with_indicators.parquet')

# Select features for each model (adjust as needed)
features = ['ema_9', 'ema_20', 'ema_50', 'ema_100', 'ema_200', 'sma_10', 'sma_20', 'sma_50',
            'rsi_14', 'rsi_7', 'macd', 'macd_signal', 'macd_diff', 'stoch_k', 'stoch_d',
            'cci_20', 'willr_14', 'roc_1', 'roc_5', 'roc_15', 'obv', 'bb_upper', 'bb_middle',
            'bb_lower', 'atr_14', 'adx_14', 'psar', 'fractal_high', 'fractal_low',
            '5m_ema_20', '5m_rsi_14', '5m_macd', '5m_bb_upper', '5m_bb_lower', '5m_atr_14', '5m_adx_14',
            '30m_ema_20', '30m_rsi_14', '30m_macd', '30m_bb_upper', '30m_bb_lower', '30m_atr_14', '30m_adx_14',
            '1h_ema_20', '1h_rsi_14', '1h_macd', '1h_bb_upper', '1h_bb_lower', '1h_atr_14', '1h_adx_14',
            '4h_ema_20', '4h_rsi_14', '4h_macd', '4h_bb_upper', '4h_bb_lower', '4h_atr_14', '4h_adx_14']

# Prepare the feature matrix for the last N rows
N = 50  # Number of samples
timesteps = 60  # Number of time steps
features_per_step = 15  # Number of features per time step

# Ensure the features list has the correct number of features
features_seq = features[:features_per_step]  # Select the first 15 features for sequence models

# Check if all features in features_seq are present in df_1m
missing_features = [f for f in features_seq if f not in df_1m.columns]

if missing_features:
    raise KeyError(f"The following features are missing from the DataFrame: {missing_features}")

# Reshape the input data to include the time steps dimension
X = df_1m[features_seq].tail(N * timesteps).values.reshape(N, timesteps, features_per_step)

# For tree models, use the last timestep's features
X_rf_xgb = X[:, -1, :]

# Make predictions
lstm_preds = lstm_model.predict(X)
gru_preds = gru_model.predict(X)
rf_preds = rf_model.predict(X_rf_xgb)
xgb_preds = xgb_model.predict(X_rf_xgb)

# Ensemble prediction (average)
ensemble_preds = np.column_stack([
    lstm_preds.flatten(),
    gru_preds.flatten(),
    rf_preds,
    xgb_preds
]).mean(axis=1)

print('Predictions complete!')
print('LSTM:', lstm_preds.flatten()[-5:])
print('GRU:', gru_preds.flatten()[-5:])
print('RF:', rf_preds[-5:])
print('XGB:', xgb_preds[-5:])
print('Ensemble:', ensemble_preds[-5:])

# --- Multi-timeframe signal logic & risk management ---
account_equity = 10000  # USD
risk_per_trade = 0.01
atr_col = '1h_atr_14'
threshold = 0.1

def multi_timeframe_signal_with_ensemble(row, ensemble_pred, threshold=0.1):
    bullish_4h = (row['close'] > row['4h_ema_20']) and (row['4h_rsi_14'] > 50)
    bearish_4h = (row['close'] < row['4h_ema_20']) and (row['4h_rsi_14'] < 50)
    bullish_1h = (row['close'] > row['1h_ema_20']) and (row['1h_rsi_14'] > 50)
    bearish_1h = (row['close'] < row['1h_ema_20']) and (row['1h_rsi_14'] < 50)
    if bullish_4h and bullish_1h and ensemble_pred > threshold:
        return "Long"
    elif bearish_4h and bearish_1h and ensemble_pred < -threshold:
        return "Short"
    else:
        return "Flat"

results = []
for i, (idx, row) in enumerate(df_1m.tail(N).iterrows()):
    ensemble_pred = ensemble_preds[i]
    signal = multi_timeframe_signal_with_ensemble(row, ensemble_pred, threshold)
    close = row['close']
    atr = row[atr_col]
    if signal == "Long":
        stop = close - 2 * atr
        target = close + 2 * atr
        risk_per_unit = close - stop
    elif signal == "Short":
        stop = close + 2 * atr
        target = close - 2 * atr
        risk_per_unit = stop - close
    else:
        stop = target = risk_per_unit = None
    if risk_per_unit and risk_per_unit > 0:
        position_size = (account_equity * risk_per_trade) / risk_per_unit
    else:
        position_size = 0
    results.append({
        'Signal': signal,
        'Entry ($)': f"${close:.2f}",
        'Stop ($)': f"${stop:.2f}" if stop is not None else None,
        'Target ($)': f"${target:.2f}" if target is not None else None,
        'Position Size': f"{position_size:.4f}",
        'Ensemble Pred': f"{ensemble_pred:.4f}"
    })

import pandas as pd
trade_df = pd.DataFrame(results)
print(trade_df.tail(10))  # Show last 10 signals