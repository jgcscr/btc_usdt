# signals.py
"""
Signal generation logic for multi-timeframe strategy.
"""
import numpy as np

def multi_timeframe_signal_with_ensemble(row, ensemble_pred, threshold=0.1):
    bullish_4h = (row['close'] > row['4h_ema_20']) and (row['4h_rsi_14'] > 50)
    bearish_4h = (row['close'] < row['4h_ema_20']) and (row['4h_rsi_14'] < 50)
    bullish_1h = (row['close'] > row['1h_ema_20']) and (row['1h_rsi_14'] > 50)
    bearish_1h = (row['close'] < row['1h_ema_20']) and (row['1h_rsi_14'] < 50)
    if bullish_4h and bullish_1h and ensemble_pred > threshold:
        return "Long"
    elif bearish_4h and bearish_1h and ensemble_pred < -threshold:
        return "Short"
    else:
        return "Flat"

def generate_signals(df, ensemble_preds, threshold=0.1):
    signals = []
    for i, row in df.iterrows():
        signal = multi_timeframe_signal_with_ensemble(row, ensemble_preds[i], threshold)
        signals.append(signal)
    return np.array(signals)
