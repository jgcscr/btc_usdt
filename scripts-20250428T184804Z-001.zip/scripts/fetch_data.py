# Binance 1m OHLCV fetch for BTCUSDT, past 365 days, saving to Parquet
import requests
import pandas as pd
import time
import os
from datetime import datetime, timedelta

# Parameters
symbol = "BTCUSDT"
interval = "1m"
limit = 1000  # Binance max per request
days = 365
file_path = "/content/drive/My Drive/data/1m_btcusdt_365_days.parquet"
api_url = "https://api.binance.us/api/v3/klines"

# Ensure output directory exists
os.makedirs(os.path.dirname(file_path), exist_ok=True)

# Calculate start and end timestamps (in ms)
end_time = int(datetime.now().timestamp() * 1000)

# Check if file exists and set start_time accordingly
if os.path.exists(file_path):
    existing_df = pd.read_parquet(file_path)
    if not existing_df.empty:
        last_time = existing_df['open_time'].max()
        # Start from the next minute
        start_time = int((last_time + pd.Timedelta(minutes=1)).timestamp() * 1000)
        print(f"Continuing from {last_time}...")
    else:
        start_time = int((datetime.now() - timedelta(days=days)).timestamp() * 1000)
        existing_df = pd.DataFrame()
else:
    existing_df = pd.DataFrame()
    start_time = int((datetime.now() - timedelta(days=days)).timestamp() * 1000)

# Prepare to collect data
all_klines = []
curr_start = start_time

print("Fetching data. This may take a while...")
print("Fetch will start from:", pd.to_datetime(start_time, unit='ms'))
print("Fetch will end at:", pd.to_datetime(end_time, unit='ms'))

while curr_start < end_time:
    params = {
        "symbol": symbol,
        "interval": interval,
        "startTime": curr_start,
        "endTime": min(curr_start + limit * 60 * 1000, end_time),
        "limit": limit
    }
    response = requests.get(api_url, params=params)
    if response.status_code != 200:
        print(f"Error: {response.status_code}, {response.text}")
        break
    klines = response.json()
    if not klines:
        break
    all_klines.extend(klines)
    # Move to next batch
    curr_start = klines[-1][0] + 60 * 1000
    time.sleep(0.25)

# Convert to DataFrame and append if needed
if all_klines:
    columns = [
        "open_time", "open", "high", "low", "close", "volume",
        "close_time", "quote_asset_volume", "number_of_trades",
        "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"
    ]
    new_df = pd.DataFrame(all_klines, columns=columns)
    new_df["open_time"] = pd.to_datetime(new_df["open_time"], unit="ms")
    new_df["close_time"] = pd.to_datetime(new_df["close_time"], unit="ms")
    if not existing_df.empty:
        df = pd.concat([existing_df, new_df], ignore_index=True)
        df = df.drop_duplicates(subset=["open_time"]).sort_values("open_time").reset_index(drop=True)
    else:
        df = new_df
    df.to_parquet(file_path, index=False)
    print(f"Saved {len(df)} rows to {file_path} in Parquet format.")
else:
    print("No new data fetched. File is up to date.")