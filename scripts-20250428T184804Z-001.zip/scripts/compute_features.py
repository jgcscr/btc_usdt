import pandas as pd
import numpy as np
import ta
import os

# Paths
raw_path = '/content/drive/My Drive/data/1m_btcusdt_365_days.parquet'
enriched_path = '/content/drive/My Drive/data/1m_btcusdt_365_days_with_indicators.parquet'

# Load raw data
raw_df = pd.read_parquet(raw_path)
raw_df['open_time'] = pd.to_datetime(raw_df['open_time'])
raw_df = raw_df.set_index('open_time')

# Determine lookback for rolling indicators
lookback = 200  # Largest window used (e.g., EMA200)

if os.path.exists(enriched_path):
    enriched_df = pd.read_parquet(enriched_path)
    enriched_df['open_time'] = pd.to_datetime(enriched_df['open_time'])
    enriched_df = enriched_df.set_index('open_time')
    last_time = enriched_df.index.max()
    # Only process new data
    new_raw = raw_df[raw_df.index > last_time].copy()
    if not new_raw.empty:
        # Get buffer rows before the first new row
        buffer = raw_df.loc[:new_raw.index[0]].tail(lookback)
        new_raw_with_buffer = pd.concat([buffer, new_raw])
    else:
        new_raw_with_buffer = pd.DataFrame()
    print(f"Existing enriched file found. Last processed: {last_time}. New rows to process: {len(new_raw)}")
else:
    enriched_df = None
    new_raw = raw_df.copy()
    new_raw_with_buffer = new_raw.copy()
    print(f"No enriched file found. Processing all {len(new_raw)} rows.")

if not new_raw_with_buffer.empty:
    # Convert columns to numeric
    for col in ['open', 'high', 'low', 'close', 'volume']:
        new_raw_with_buffer[col] = pd.to_numeric(new_raw_with_buffer[col], errors='coerce')

    # --- 1m Indicators ---
    new_raw_with_buffer['ema_9'] = ta.trend.ema_indicator(new_raw_with_buffer['close'], window=9)
    new_raw_with_buffer['ema_20'] = ta.trend.ema_indicator(new_raw_with_buffer['close'], window=20)
    new_raw_with_buffer['ema_50'] = ta.trend.ema_indicator(new_raw_with_buffer['close'], window=50)
    new_raw_with_buffer['ema_100'] = ta.trend.ema_indicator(new_raw_with_buffer['close'], window=100)
    new_raw_with_buffer['ema_200'] = ta.trend.ema_indicator(new_raw_with_buffer['close'], window=200)
    new_raw_with_buffer['sma_10'] = ta.trend.sma_indicator(new_raw_with_buffer['close'], window=10)
    new_raw_with_buffer['sma_20'] = ta.trend.sma_indicator(new_raw_with_buffer['close'], window=20)
    new_raw_with_buffer['sma_50'] = ta.trend.sma_indicator(new_raw_with_buffer['close'], window=50)
    new_raw_with_buffer['rsi_14'] = ta.momentum.rsi(new_raw_with_buffer['close'], window=14)
    new_raw_with_buffer['rsi_7'] = ta.momentum.rsi(new_raw_with_buffer['close'], window=7)
    new_raw_with_buffer['macd'] = ta.trend.macd(new_raw_with_buffer['close'])
    new_raw_with_buffer['macd_signal'] = ta.trend.macd_signal(new_raw_with_buffer['close'])
    new_raw_with_buffer['macd_diff'] = ta.trend.macd_diff(new_raw_with_buffer['close'])
    new_raw_with_buffer['stoch_k'] = ta.momentum.stoch(new_raw_with_buffer['high'], new_raw_with_buffer['low'], new_raw_with_buffer['close'])
    new_raw_with_buffer['stoch_d'] = ta.momentum.stoch_signal(new_raw_with_buffer['high'], new_raw_with_buffer['low'], new_raw_with_buffer['close'])
    new_raw_with_buffer['cci_20'] = ta.trend.cci(new_raw_with_buffer['high'], new_raw_with_buffer['low'], new_raw_with_buffer['close'], window=20)
    new_raw_with_buffer['willr_14'] = ta.momentum.williams_r(new_raw_with_buffer['high'], new_raw_with_buffer['low'], new_raw_with_buffer['close'], lbp=14)
    new_raw_with_buffer['roc_1'] = ta.momentum.roc(new_raw_with_buffer['close'], window=1)
    new_raw_with_buffer['roc_5'] = ta.momentum.roc(new_raw_with_buffer['close'], window=5)
    new_raw_with_buffer['roc_15'] = ta.momentum.roc(new_raw_with_buffer['close'], window=15)
    new_raw_with_buffer['obv'] = ta.volume.on_balance_volume(new_raw_with_buffer['close'], new_raw_with_buffer['volume'])
    bb = ta.volatility.BollingerBands(new_raw_with_buffer['close'], window=20, window_dev=2)
    new_raw_with_buffer['bb_upper'] = bb.bollinger_hband()
    new_raw_with_buffer['bb_middle'] = bb.bollinger_mavg()
    new_raw_with_buffer['bb_lower'] = bb.bollinger_lband()
    new_raw_with_buffer['atr_14'] = ta.volatility.average_true_range(new_raw_with_buffer['high'], new_raw_with_buffer['low'], new_raw_with_buffer['close'], window=14)
    new_raw_with_buffer['adx_14'] = ta.trend.adx(new_raw_with_buffer['high'], new_raw_with_buffer['low'], new_raw_with_buffer['close'], window=14)
    new_raw_with_buffer['psar'] = ta.trend.psar_up(new_raw_with_buffer['high'], new_raw_with_buffer['low'], new_raw_with_buffer['close'])
    new_raw_with_buffer['fractal_high'] = new_raw_with_buffer['high'].rolling(window=5, center=True).max()
    new_raw_with_buffer['fractal_low'] = new_raw_with_buffer['low'].rolling(window=5, center=True).min()

    # --- Resample and compute indicators for higher timeframes ---
    def compute_htf_features(df, rule, prefix):
        df_htf = df.resample(rule).agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        }).dropna()
        min_rows = 20  # Largest window used in this function
        if len(df_htf) < min_rows:
            print(f"Not enough data to compute {prefix} features (have {len(df_htf)} rows). Skipping.")
            return pd.DataFrame(index=df_htf.index)
        df_htf[f'{prefix}_ema_20'] = ta.trend.ema_indicator(df_htf['close'], window=20)
        df_htf[f'{prefix}_rsi_14'] = ta.momentum.rsi(df_htf['close'], window=14)
        df_htf[f'{prefix}_macd'] = ta.trend.macd(df_htf['close'])
        bb = ta.volatility.BollingerBands(df_htf['close'], window=20, window_dev=2)
        df_htf[f'{prefix}_bb_upper'] = bb.bollinger_hband()
        df_htf[f'{prefix}_bb_lower'] = bb.bollinger_lband()
        df_htf[f'{prefix}_atr_14'] = ta.volatility.average_true_range(df_htf['high'], df_htf['low'], df_htf['close'], window=14)
        df_htf[f'{prefix}_adx_14'] = ta.trend.adx(df_htf['high'], df_htf['low'], df_htf['close'], window=14)
        return df_htf[[f'{prefix}_ema_20', f'{prefix}_rsi_14', f'{prefix}_macd', f'{prefix}_bb_upper', f'{prefix}_bb_lower', f'{prefix}_atr_14', f'{prefix}_adx_14']]

    for rule, prefix in [('5T', '5m'), ('30T', '30m'), ('1H', '1h'), ('4H', '4h')]:
        htf = compute_htf_features(new_raw_with_buffer, rule, prefix)
        if not htf.empty:
            new_raw_with_buffer = new_raw_with_buffer.merge(htf, left_index=True, right_index=True, how='left')
            new_raw_with_buffer.fillna(method='ffill', inplace=True)
        else:
            print(f"Skipped merging {prefix} features due to insufficient data.")

    # Drop rows with NaNs from indicator warm-up
    new_raw_with_buffer = new_raw_with_buffer.dropna().reset_index()

    # Only keep rows with open_time > last_time (i.e., drop buffer rows)
    if os.path.exists(enriched_path):
        # Ensure open_time is a column and compare as Timestamps
        if 'open_time' in new_raw_with_buffer.columns:
            mask = pd.to_datetime(new_raw_with_buffer['open_time']) > pd.to_datetime(last_time)
            new_features = new_raw_with_buffer[mask]
        else:
            # If open_time is index
            mask = new_raw_with_buffer.index > pd.to_datetime(last_time)
            new_features = new_raw_with_buffer[mask]
    else:
        new_features = new_raw_with_buffer
else:
    print("No new rows to process.")

# Combine with existing enriched data and save
# When saving, reset_index so 'open_time' is a column
if enriched_df is not None and not new_features.empty:
    combined = pd.concat([enriched_df, new_features], axis=0).reset_index(drop=True)
    # Deduplicate by 'open_time' column and sort
    combined = combined.drop_duplicates(subset=['open_time']).sort_values('open_time').reset_index(drop=True)
    combined.to_parquet(enriched_path, index=False)
    print(f"Appended {len(new_features)} new rows. Total rows: {len(combined)}. Saved to {enriched_path}.")
elif enriched_df is None and not new_features.empty:
    new_features = new_features.reset_index(drop=True)
    new_features.to_parquet(enriched_path, index=False)
    print(f"Saved {len(new_features)} rows to {enriched_path}.")
else:
    print("No update needed. Enriched file is up to date.")