# utils.py
"""
Utility functions for logging, configuration, and metrics.
"""
import logging
import os
import json

def setup_logger(log_path='strategy.log'):
    logging.basicConfig(
        filename=log_path,
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s',
    )
    return logging.getLogger()

def save_json(data, path):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def load_json(path):
    if not os.path.exists(path):
        return None
    with open(path, 'r') as f:
        return json.load(f)

def print_trade_summary(trade_log):
    print(f"Total trades: {len(trade_log)}")
    if trade_log:
        wins = [t for t in trade_log if (t['Type'] == 'Long' and t.get('Exit', 0) > t['Entry']) or (t['Type'] == 'Short' and t.get('Exit', 0) < t['Entry'])]
        print(f"Winning trades: {len(wins)}")
        print(f"Win rate: {len(wins)/len(trade_log)*100:.2f}%")
        print(f"Last trade: {trade_log[-1]}")
    else:
        print("No trades executed.")
