import pandas as pd
import numpy as np
from ta import add_all_ta_features
from ta.utils import dropna

def calculate_technical_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate technical indicators for the given DataFrame.
    
    Args:
        df (pd.DataFrame): DataFrame with OHLCV data
        
    Returns:
        pd.DataFrame: DataFrame with technical indicators
    """
    try:
        # Ensure DataFrame has required columns
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        if not all(col in df.columns for col in required_columns):
            raise ValueError(f"DataFrame must have columns: {required_columns}")
            
        # Clean NaN values
        df = dropna(df)
        
        # Add all technical analysis features
        df = add_all_ta_features(
            df,
            open="open",
            high="high",
            low="low",
            close="close",
            volume="volume",
            fillna=True
        )
        
        return df
        
    except Exception as e:
        print(f"Error calculating technical indicators: {str(e)}")
        raise