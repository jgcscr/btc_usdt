# btc_prediction/src/utils/technical.py

"""
Technical indicator processor for BTC/USDT data.
Runs every 4 hours to compute trend, momentum, volatility and volume indicators.
"""

import logging
from pathlib import Path
import pandas as pd
from ta import add_all_ta_features
from typing import Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class IndicatorProcessor:
    """Handles technical indicator calculations for cryptocurrency data."""
    
    def __init__(self):
        self.raw_path = Path('data/raw/btcusdt_1h_365_days.parquet')
        self.processed_path = Path('data/processed/btcusdt_1h_365_days_with_indicators.parquet')
        
        # Required columns for technical analysis
        self.required_columns = {'open', 'high', 'low', 'close', 'volume'}

    def validate_data(self, df: pd.DataFrame) -> bool:
        """Validate input data has required columns and no NaN values."""
        try:
            # Check for required columns
            if not self.required_columns.issubset(df.columns):
                missing = self.required_columns - set(df.columns)
                raise ValueError(f"Missing required columns: {missing}")
            
            # Check for NaN values
            if df[list(self.required_columns)].isna().any().any():
                raise ValueError("Data contains NaN values in required columns")
                
            return True
            
        except Exception as e:
            logger.error(f"Data validation failed: {str(e)}")
            return False

    def read_data(self) -> Optional[pd.DataFrame]:
        """Read and validate input data."""
        try:
            df = pd.read_parquet(self.raw_path)
            if self.validate_data(df):
                return df
        except Exception as e:
            logger.error(f"Error reading data: {str(e)}")
        return None

    def compute_indicators(self, df: pd.DataFrame) -> Optional[pd.DataFrame]:
        """Compute technical indicators using TA library."""
        try:
            return add_all_ta_features(
                df,
                open="open",
                high="high",
                low="low",
                close="close",
                volume="volume",
                fillna=True
            )
        except Exception as e:
            logger.error(f"Error computing indicators: {str(e)}")
            return None

    def save_results(self, df: pd.DataFrame) -> bool:
        """Save processed data to parquet file."""
        try:
            self.processed_path.parent.mkdir(parents=True, exist_ok=True)
            df.to_parquet(self.processed_path)
            logger.info(f"Saved processed data to {self.processed_path}")
            return True
        except Exception as e:
            logger.error(f"Error saving results: {str(e)}")
            return False

    def process(self) -> bool:
        """Main processing pipeline."""
        try:
            logger.info("Starting indicator processing")
            
            # Read and validate data
            df = self.read_data()
            if df is None:
                return False
                
            # Compute indicators
            df_with_indicators = self.compute_indicators(df)
            if df_with_indicators is None:
                return False
                
            # Save results
            return self.save_results(df_with_indicators)
            
        except Exception as e:
            logger.error(f"Processing failed: {str(e)}")
            return False

def process_indicators() -> bool:
    """Entry point for indicator processing."""
    processor = IndicatorProcessor()
    return processor.process()

if __name__ == '__main__':
    success = process_indicators()
    exit_code = 0 if success else 1
    exit(exit_code)