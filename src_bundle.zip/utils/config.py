# src/utils/config.py
import yaml
from pathlib import Path
from typing import Dict, Any

class Config:
    """Configuration loader and manager."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        self.config_path = Path(config_path)
        self.config = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {self.config_path}")
            
        with open(self.config_path, 'r') as file:
            return yaml.safe_load(file)
    
    def get_path(self, key: str) -> Path:
        """Get path from config and ensure it exists."""
        path = Path(self.config['paths'][key])
        path.mkdir(parents=True, exist_ok=True)
        return path
    
    def get(self, *keys: str) -> Any:
        """Get nested configuration value."""
        value = self.config
        for key in keys:
            value = value[key]
        return value
